nvcc -fmad=false -arch=sm_52 SMMatMul.cu -o SMMatMul
