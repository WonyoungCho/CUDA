#include <stdlib.h>
#include <stdio.h>
#include "common.h"
//#define N	10
//void initialVec(int *Vec, int val, int size)
//{
//	int i;
//	for(i=0;i<size;i++)
//		Vec[i]=val;
//}
float AddInner(float *A, float *B, int size)
{
	int i;
	float sum=0.0f;
	for(i=0;i<size;i++)
		sum += A[i]*B[i];
	return sum;
}
int main(int argc, char **argv)
{
	float *VecA, *VecB;
	int i,N=10;
	float inner;
	if(argc>1) N=atoi(argv[1]);
	VecA=(float*)malloc(N*sizeof(float));
	VecB=(float*)malloc(N*sizeof(float));
	initialData(VecA, N);
	initialData(VecB, N);
	inner=AddInner(VecA, VecB, N);

	printf("Inner prodcut of VecA and VecB is %f\n",inner);

	free(VecA);
	free(VecB);
	return 0;
}
