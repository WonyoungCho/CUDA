void initialData(float *ip, int size)
{
	// generate diffeent seed for random number
	time_t t;
	int i;
//	srand((unsigned) time(&t));	// seed
	for( i=0;i<size;i++)
		ip[i]=(float)(rand())/RAND_MAX;
}
