#include <stdlib.h>
#include <stdio.h>
#include "common.h"
void MatMul(float *A, float *B, float *C, int n, int m)
{
	int i,j,k;
	float sum;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			sum = 0.0f;
			for(k=0;k<m;k++)
			{
				sum += A[i*m+k]*B[k*n+j];
			}
			C[i*n+j]=sum;
		}

	}
}
int main(int argc, char **argv)
{
	float *MatA, *MatB, *MatC;
	int nrows=10, ncols=20;
	int size;
	if(argc>1) nrows=atoi(argv[1]);
	if(argc>2) ncols=atoi(argv[2]);
	size=nrows*ncols;

	MatA=(float*)malloc(size*sizeof(float));
	MatB=(float*)malloc(size*sizeof(float));
	MatC=(float*)malloc(nrows*nrows*sizeof(float));
	initialData(MatA, size);
	initialData(MatA, size);

	MatMul(MatA, MatB, MatC,nrows,ncols);

	free(MatA);
	free(MatB);
	free(MatC);
	return 0;
}
