#include <string.h>
#include <stdio.h>

int main(void)
{
	int array[10]={0,1,2,3,4,5,6,7,8,9};
	int i;
	for(i=0;i<10;i++)
		printf("array[%d]=%d\n",i,array[i]);

	memset((int*)array, 0,10*sizeof(int));
	for(i=0;i<10;i++)
		printf("array[%d]=%d\n",i,array[i]);
	return 0;


}
