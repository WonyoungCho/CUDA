#include <string.h>
#include <stdlib.h>
#include <stdio.h>
int main(void)
{
	int array[10]={0,1,2,3,4,5,6,7,8,9};
	int *ptr_dest;
	int i;
	ptr_dest=(int*)malloc(10*sizeof(int));
	memcpy((int*)ptr_dest, (int*)array, 10*sizeof(int));
	for(i=0;i<10;i++)
		printf("ptr_dest[%d]=%d\n",i,ptr_dest[i]);

	free(ptr_dest);

	return 0;
}
