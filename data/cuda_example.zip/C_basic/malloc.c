#include <stdlib.h>
#include <stdio.h>
int main(void)
{
	int *ptr_int;
	int i;
	ptr_int=(int*)malloc(10*sizeof(int));
	for(i=0;i<10;i++)
	{
		ptr_int[i]=i;
		printf("ptr_int[%d]=%d\n",i,ptr_int[i]);
	}
	free(ptr_int);
	return 0;
}
