#include <stdlib.h>
#include <stdio.h>
#include "common.h"
void AddVec(float *A, float *B, float *C, int size)
{
	int i;
	for(i=0;i<size;i++)
		C[i]=A[i]+B[i];
}
int main(int argc, char **argv)
{
	float *VecA, *VecB, *VecC;
	int i,N;
	N=10;
	if(argc >1 ) N = atoi(argv[1]);
	VecA=(float*)malloc(N*sizeof(float));
	VecB=(float*)malloc(N*sizeof(float));
	VecC=(float*)malloc(N*sizeof(float));

	initialData(VecA, N);
	initialData(VecB, N);
	AddVec(VecA, VecB, VecC, N);
	for(i=0;i<N;i++)
	{
		printf("VecC[%d] = VecA[%d] + VecB[%d] = %f + %f = %f\n",i,i,i,VecA[i],VecB[i],VecC[i]);
	}

	free(VecA);
	free(VecB);
	free(VecC);
	return 0;
}
