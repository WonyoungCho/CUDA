nvcc -arch=sm_52 -fmad=false ./MatMul.cu -o MatMul
