#nvcc –arch=sm_35 –rdc=true HelloWorld.cu –o HelloWorld -lcudadevrt
nvcc -arch=sm_35 -rdc=true HelloWorld.cu -o HelloWorld -lcudadevrt

